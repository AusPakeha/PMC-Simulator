class CfgSounds
{	
	sounds[] = {};
	
	class Flies_SFX{name = "Flies_SFX";sound[] = {"scripts\GF_Blood_Stains_LITE\Flies_SFX.ogg", db0, 1.0};titles[] = {};};
	
	//__________________________ GF_SFX_Bullet_Impact  __________________________
		
	class Bullet_Impact_1{name = "Bullet_Impact_1";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Bullet_Impact\GF_SFX_Bullet_Impact_Sounds\Bullet_Impact_1.ogg", db0, 1.0};titles[] = {};};
	class Bullet_Impact_2{name = "Bullet_Impact_2";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Bullet_Impact\GF_SFX_Bullet_Impact_Sounds\Bullet_Impact_2.ogg", db0, 1.0};titles[] = {};};
	class Bullet_Impact_3{name = "Bullet_Impact_3";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Bullet_Impact\GF_SFX_Bullet_Impact_Sounds\Bullet_Impact_3.ogg", db0, 1.0};titles[] = {};};
	class Bullet_Impact_4{name = "Bullet_Impact_4";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Bullet_Impact\GF_SFX_Bullet_Impact_Sounds\Bullet_Impact_4.ogg", db0, 1.0};titles[] = {};};
	class Bullet_Impact_5{name = "Bullet_Impact_5";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Bullet_Impact\GF_SFX_Bullet_Impact_Sounds\Bullet_Impact_5.ogg", db0, 1.0};titles[] = {};};
	class Bullet_Impact_6{name = "Bullet_Impact_6";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Bullet_Impact\GF_SFX_Bullet_Impact_Sounds\Bullet_Impact_6.ogg", db0, 1.0};titles[] = {};};
	class Bullet_Impact_7{name = "Bullet_Impact_7";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Bullet_Impact\GF_SFX_Bullet_Impact_Sounds\Bullet_Impact_7.ogg", db0, 1.0};titles[] = {};};
	class Bullet_Impact_8{name = "Bullet_Impact_8";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Bullet_Impact\GF_SFX_Bullet_Impact_Sounds\Bullet_Impact_8.ogg", db0, 1.0};titles[] = {};};
	class Bullet_Impact_9{name = "Bullet_Impact_9";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Bullet_Impact\GF_SFX_Bullet_Impact_Sounds\Bullet_Impact_9.ogg", db0, 1.0};titles[] = {};};
	class Bullet_Impact_10{name = "Bullet_Impact_10";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Bullet_Impact\GF_SFX_Bullet_Impact_Sounds\Bullet_Impact_10.ogg", db0, 1.0};titles[] = {};};
	class Bullet_Impact_11{name = "Bullet_Impact_11";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Bullet_Impact\GF_SFX_Bullet_Impact_Sounds\Bullet_Impact_11.ogg", db0, 1.0};titles[] = {};};
	class Bullet_Impact_12{name = "Bullet_Impact_12";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Bullet_Impact\GF_SFX_Bullet_Impact_Sounds\Bullet_Impact_12.ogg", db0, 1.0};titles[] = {};};
	class Bullet_Impact_13{name = "Bullet_Impact_13";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Bullet_Impact\GF_SFX_Bullet_Impact_Sounds\Bullet_Impact_13.ogg", db0, 1.0};titles[] = {};};
	class Bullet_Impact_14{name = "Bullet_Impact_14";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Bullet_Impact\GF_SFX_Bullet_Impact_Sounds\Bullet_Impact_14.ogg", db0, 1.0};titles[] = {};};
	class Bullet_Impact_15{name = "Bullet_Impact_15";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Bullet_Impact\GF_SFX_Bullet_Impact_Sounds\Bullet_Impact_15.ogg", db0, 1.0};titles[] = {};};
	
	
	//__________________________ GF_SFX_Killed_LITE  __________________________
	
	class Killed_3{name = "Killed_3";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Killed_LITE\GF_SFX_Killed_Sounds\Killed_3.ogg", db0, 1.0};titles[] = {};};
	class Killed_5{name = "Killed_5";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Killed_LITE\GF_SFX_Killed_Sounds\Killed_5.ogg", db0, 1.0};titles[] = {};};
	class Killed_6{name = "Killed_6";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Killed_LITE\GF_SFX_Killed_Sounds\Killed_6.ogg", db0, 1.0};titles[] = {};};
	class Killed_8{name = "Killed_8";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Killed_LITE\GF_SFX_Killed_Sounds\Killed_8.ogg", db-2, 1.0};titles[] = {};};
	class Killed_9{name = "Killed_9";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Killed_LITE\GF_SFX_Killed_Sounds\Killed_9.ogg", db0, 1.0};titles[] = {};};
	class Killed_10{name = "Killed_10";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Killed_LITE\GF_SFX_Killed_Sounds\Killed_10.ogg", db0, 1.0};titles[] = {};};
	class Killed_11{name = "Killed_11";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Killed_LITE\GF_SFX_Killed_Sounds\Killed_11.ogg", db0, 1.0};titles[] = {};};
	class Killed_12{name = "Killed_12";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Killed_LITE\GF_SFX_Killed_Sounds\Killed_12.ogg", db0, 1.0};titles[] = {};};
	class Killed_13{name = "Killed_13";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Killed_LITE\GF_SFX_Killed_Sounds\Killed_13.ogg", db0, 1.0};titles[] = {};};
	class Killed_14{name = "Killed_14";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Killed_LITE\GF_SFX_Killed_Sounds\Killed_14.ogg", db0, 1.0};titles[] = {};};
	class Killed_15{name = "Killed_15";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Killed_LITE\GF_SFX_Killed_Sounds\Killed_15.ogg", db0, 1.0};titles[] = {};};
	
	//__________________________ GF_SFX_Screaming  __________________________
	
	class Screaming_1{name = "Screaming_1";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_1.ogg", db0, 1.0};titles[] = {};};
	class Screaming_2{name = "Screaming_2";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_2.ogg", db0, 1.0};titles[] = {};};
	class Screaming_3{name = "Screaming_3";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_3.ogg", db0, 1.0};titles[] = {};};
	class Screaming_4{name = "Screaming_4";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_4.ogg", db0, 1.0};titles[] = {};};
	class Screaming_5{name = "Screaming_5";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_5.ogg", db0, 1.0};titles[] = {};};
	class Screaming_6{name = "Screaming_6";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_6.ogg", db0, 1.0};titles[] = {};};
	class Screaming_7{name = "Screaming_7";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_7.ogg", db0, 1.0};titles[] = {};};
	class Screaming_8{name = "Screaming_8";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_8.ogg", db0, 1.0};titles[] = {};};
	class Screaming_9{name = "Screaming_9";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_9.ogg", db0, 1.0};titles[] = {};};
	class Screaming_10{name = "Screaming_10";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_10.ogg", db0, 1.0};titles[] = {};};
	class Screaming_11{name = "Screaming_11";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_11.ogg", db0, 1.0};titles[] = {};};
	class Screaming_12{name = "Screaming_12";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_12.ogg", db0, 1.0};titles[] = {};};
	class Screaming_13{name = "Screaming_13";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_13.ogg", db0, 1.0};titles[] = {};};
	class Screaming_14{name = "Screaming_14";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_14.ogg", db0, 1.0};titles[] = {};};
	class Screaming_15{name = "Screaming_15";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_15.ogg", db0, 1.0};titles[] = {};};
	class Screaming_16{name = "Screaming_16";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_16.ogg", db0, 1.0};titles[] = {};};
	class Screaming_17{name = "Screaming_17";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_17.ogg", db0, 1.0};titles[] = {};};
	class Screaming_18{name = "Screaming_18";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_18.ogg", db0, 1.0};titles[] = {};};
	class Screaming_19{name = "Screaming_19";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_19.ogg", db0, 1.0};titles[] = {};};
	class Screaming_20{name = "Screaming_20";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_20.ogg", db0, 1.0};titles[] = {};};
	class Screaming_21{name = "Screaming_21";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_21.ogg", db0, 1.0};titles[] = {};};
	class Screaming_22{name = "Screaming_22";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_22.ogg", db0, 1.0};titles[] = {};};
	class Screaming_23{name = "Screaming_23";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_23.ogg", db0, 1.0};titles[] = {};};
	class Screaming_24{name = "Screaming_24";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_24.ogg", db0, 1.0};titles[] = {};};
	class Screaming_25{name = "Screaming_25";sound[] = {"scripts\GF_Blood_Stains_LITE\GF_SFX\GF_SFX_Screaming\GF_SFX_Screaming_Sounds\Screaming_25.ogg", db0, 1.0};titles[] = {};};
	
	class Birds_day_1{name = "Birds_day_1";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_1.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_2{name = "Birds_day_2";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_2.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_3{name = "Birds_day_3";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_3.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_4{name = "Birds_day_4";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_4.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_5{name = "Birds_day_5";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_5.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_6{name = "Birds_day_6";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_6.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_7{name = "Birds_day_7";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_7.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_8{name = "Birds_day_8";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_8.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_9{name = "Birds_day_9";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_9.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_10{name = "Birds_day_10";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_10.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_11{name = "Birds_day_11";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_11.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_12{name = "Birds_day_12";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_12.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_13{name = "Birds_day_13";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_13.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_14{name = "Birds_day_14";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_14.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_15{name = "Birds_day_15";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_15.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_16{name = "Birds_day_16";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_16.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_17{name = "Birds_day_17";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_17.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_18{name = "Birds_day_18";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_18.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_19{name = "Birds_day_19";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_19.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_20{name = "Birds_day_20";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_20.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_21{name = "Birds_day_21";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_21.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_22{name = "Birds_day_22";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_22.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_23{name = "Birds_day_23";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_23.ogg", db0, 1.0};titles[] = {};};
	class Birds_day_24{name = "Birds_day_24";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_day\Birds_day_24.ogg", db0, 1.0};titles[] = {};};
	
	
	//__________________________	Birds_night	__________________________
	
	class Birds_night_1{name = "Birds_night_1";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_1.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_2{name = "Birds_night_2";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_2.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_3{name = "Birds_night_3";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_3.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_4{name = "Birds_night_4";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_4.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_5{name = "Birds_night_5";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_5.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_6{name = "Birds_night_6";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_6.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_7{name = "Birds_night_7";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_7.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_8{name = "Birds_night_8";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_8.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_9{name = "Birds_night_9";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_9.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_10{name = "Birds_night_10";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_10.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_11{name = "Birds_night_11";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_11.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_12{name = "Birds_night_12";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_12.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_13{name = "Birds_night_13";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_13.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_14{name = "Birds_night_14";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_14.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_15{name = "Birds_night_15";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_15.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_16{name = "Birds_night_16";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_16.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_17{name = "Birds_night_17";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_17.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_18{name = "Birds_night_18";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_18.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_19{name = "Birds_night_19";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_19.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_20{name = "Birds_night_20";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_20.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_21{name = "Birds_night_21";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_21.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_22{name = "Birds_night_22";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_22.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_23{name = "Birds_night_23";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_23.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_24{name = "Birds_night_24";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_24.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_25{name = "Birds_night_25";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_25.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_26{name = "Birds_night_26";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_26.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_27{name = "Birds_night_27";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_27.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_28{name = "Birds_night_28";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_28.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_29{name = "Birds_night_29";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_29.ogg", db0, 1.0};titles[] = {};};
	class Birds_night_30{name = "Birds_night_30";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Birds_night\Birds_night_30.ogg", db0, 1.0};titles[] = {};};
	
	
	//__________________________	Insects_day	__________________________
	
	class Insects_day_1{name = "Insects_day_1";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_day\Insects_day_1.ogg", db0, 1.0};titles[] = {};};
	class Insects_day_2{name = "Insects_day_2";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_day\Insects_day_2.ogg", db0, 1.0};titles[] = {};};
	class Insects_day_3{name = "Insects_day_3";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_day\Insects_day_3.ogg", db0, 1.0};titles[] = {};};
	class Insects_day_4{name = "Insects_day_4";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_day\Insects_day_4.ogg", db0, 1.0};titles[] = {};};
	class Insects_day_5{name = "Insects_day_5";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_day\Insects_day_5.ogg", db0, 1.0};titles[] = {};};
	class Insects_day_6{name = "Insects_day_6";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_day\Insects_day_6.ogg", db0, 1.0};titles[] = {};};
	class Insects_day_7{name = "Insects_day_7";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_day\Insects_day_7.ogg", db0, 1.0};titles[] = {};};
	class Insects_day_8{name = "Insects_day_8";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_day\Insects_day_8.ogg", db0, 1.0};titles[] = {};};
	class Insects_day_9{name = "Insects_day_9";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_day\Insects_day_9.ogg", db0, 1.0};titles[] = {};};
	class Insects_day_10{name = "Insects_day_10";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_day\Insects_day_10.ogg", db0, 1.0};titles[] = {};};


	//__________________________	Insects_night	__________________________
	
	class Insects_night_1{name = "Insects_night_1";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_night\Insects_night_1.ogg", db0, 1.0};titles[] = {};};
	class Insects_night_2{name = "Insects_night_2";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_night\Insects_night_2.ogg", db0, 1.0};titles[] = {};};
	class Insects_night_3{name = "Insects_night_3";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_night\Insects_night_3.ogg", db0, 1.0};titles[] = {};};
	class Insects_night_4{name = "Insects_night_4";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_night\Insects_night_4.ogg", db0, 1.0};titles[] = {};};
	class Insects_night_5{name = "Insects_night_5";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_night\Insects_night_5.ogg", db0, 1.0};titles[] = {};};
	class Insects_night_6{name = "Insects_night_6";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_night\Insects_night_6.ogg", db0, 1.0};titles[] = {};};
	class Insects_night_7{name = "Insects_night_7";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_night\Insects_night_7.ogg", db0, 1.0};titles[] = {};};
	class Insects_night_8{name = "Insects_night_8";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_night\Insects_night_8.ogg", db0, 1.0};titles[] = {};};
	class Insects_night_9{name = "Insects_night_9";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_night\Insects_night_9.ogg", db0, 1.0};titles[] = {};};
	class Insects_night_10{name = "Insects_night_10";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_night\Insects_night_10.ogg", db0, 1.0};titles[] = {};};
	class Insects_night_11{name = "Insects_night_11";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Insects_night\Insects_night_11.ogg", db0, 1.0};titles[] = {};};

	
	//__________________________	SFX_Forest	__________________________
	
	class Wood_1{name = "Wood_1";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\SFX_Forest\Wood_1.ogg", db-10, 1.0};titles[] = {};};
	class Wood_2{name = "Wood_2";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\SFX_Forest\Wood_2.ogg", db-10, 1.0};titles[] = {};};
	class Wood_3{name = "Wood_3";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\SFX_Forest\Wood_3.ogg", db-10, 1.0};titles[] = {};};
	class Wood_4{name = "Wood_4";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\SFX_Forest\Wood_4.ogg", db-10, 1.0};titles[] = {};};
	class Wood_5{name = "Wood_5";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\SFX_Forest\Wood_5.ogg", db-10, 1.0};titles[] = {};};
	class Wood_6{name = "Wood_6";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\SFX_Forest\Wood_6.ogg", db-10, 1.0};titles[] = {};};
	class Wood_7{name = "Wood_7";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\SFX_Forest\Wood_7.ogg", db-10, 1.0};titles[] = {};};


	//__________________________	Wind	__________________________
	
	class Wind_Loop_1{name = "Wind_Loop_1";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Wind\Wind_Loop_1.ogg", db0, 1.0};titles[] = {};};
	class Wind_Loop_2{name = "Wind_Loop_2";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Wind\Wind_Loop_2.ogg", db0, 1.0};titles[] = {};};
	

	//__________________________	Ambiance	__________________________
	
	class Ambiance_day_1{name = "Ambiance_day_1";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Ambiance\Ambiance_day_1.ogg", db+5, 1.0};titles[] = {};};	
	class Ambiance_night_1{name = "Ambiance_night_1";sound[] = {"scripts\GF_Ambient_Environment_Sounds\Sounds\Ambiance\Ambiance_night_1.ogg", db+5, 1.0};titles[] = {};};
};