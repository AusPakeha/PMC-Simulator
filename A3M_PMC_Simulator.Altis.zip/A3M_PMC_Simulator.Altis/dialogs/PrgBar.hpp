class HGF {
	class HGF_GUI {
		file = "Functions";
		class progressBar {};
	};
};
