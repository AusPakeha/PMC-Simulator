class CfgFunctions {
    class A3M {
        class data {
            class getData {};
            class setData {};
            class putData {};
            class delData {};
        };
        class fleet {
            class ACE3support {};
            class EFheli {};
            class EFwheeled {};
            class handleModClick {};
            class heli {};
            class RFheli {};
            class RFwheeled {};
            class RHSheli {};
            class RHSsupport {};
            class RHSwheeled {};
            class RHSwinged {};
            class robotics {};
            class Support {};
            class Upgrades {};
            class vBuyButton {};
            class wheeled {};
            class winged {};
            class WSarmor {};
            class WSheli {};
            class WSrobotics {};
            class WSsupport {};
            class WSwheeled {};
        };
    };
};
